
# Changelog

## v0.1.0
- Initial release of Gradio UI (Generate, Assess, Batch Assess)
- Windows-first setup instructions
- Hugging Face Spaces deployment guide
